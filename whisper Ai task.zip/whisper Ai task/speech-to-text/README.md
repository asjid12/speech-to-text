---
title: Speech To Text
emoji: 📉
colorFrom: blue
colorTo: green
sdk: gradio
sdk_version: 5.16.0
app_file: app.py
pinned: false
license: mit
short_description: made it with whisper Ai
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
